angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $timeout,$http) {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  // Form data for the login modal
  $scope.loginData = {};

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.login = function() {
    $scope.modal.show();
  };

  // Perform the login action when the user submits the login form
  $scope.doLogin = function() {
    console.log('Doing login', $scope.loginData);

    // Simulate a login delay. Remove this and replace with your login
    // code if using a login system
    $timeout(function() {
      $scope.closeLogin();
    }, 1000);
  };
})

.controller('PlaylistsCtrl', function($scope,$http) {
  // variables
  $scope.stepsQa = [];
  $scope.viewStep = 0;
  // variables end

  $scope.getQa = function(){
    $http.get('https://rocky-sea-46108.herokuapp.com/api/questionsanswers').then(function(response){
      if (response.data.status == "success") {
        console.log(response,'response');
        $scope.stepsQa = response.data.data;
      }
    })
  };
  $scope.getQa();

  $scope.schoolList = ['Karthika High School', 'Michael High School','Holy Cross High School'];

  // $scope.stepsQa = [
  // {
  //   "question" : "During an auspicious occasion in a Hindu family, Ramya invites all her friends. Now, some of her friends are Muslims and they have come to the ceremony wearing black burqa. Ramya’s family considers black to be an unlucky colour and they are disturbed. Seeing the family disturbed, Ramya gets panicked. What will you do in this situation?",
  //   "chooseAns" : [
  //   "Agree with the family that the girls shouldn’t have worn black burqa.",
  //   "Help Ramya calm down and make the family understand that in some cultures or families, it is not considered unlucky to wear a black dress on an auspicious occasion",
  //   "Help Ramya and her family calm down and explain to the girls that they shouldn’t have worn black burqa."
  //   ]
  // },
  // {
  //   "question" : "The Work Experience teacher announces in a Standard 4 class – Since Ganesh Chaturthi is approaching, let us learn how to make a Ganpati using clay. Hearing this, a child, very innocently asks – Teacher, I am not a Hindu. How can I make Ganpati? What will you say to the child in this situation?",
  //   "chooseAns" : [
  //   "Oh! Then it is all right if you do not participate in the activity. You can make something else with the clay.",
  //   "You have to listen to your teacher!",
  //   "Even if you are not a Hindu, you can still make Ganpati and gift it to your friend."
  //   ]
  // },
  // {
  //   "question" : "A day after a pooja at her place, Tushari gives prashad to all her friends in her class. Some of her friends throw it away in the dust bin. What will be your reaction?",
  //   "chooseAns" : [
  //   "I will explain to them that prashad is food and food should not be wasted.",
  //   "I will make them understand that all of us prepare special food during auspicious occasions. And that special food should be respected and eaten and not wasted.",
  //   "I will not say anything as I believe that her friends belonged to a different religion where they do not believe in eating prashad.",
  //   ]
  // },
  // {
  //   "question" : "Seeing a Christian family prepare to go to the church for a prayer meeting, another family remarks, “Look at the way they have dressed to go to the church.” What is your view?",
  //   "chooseAns" : [
  //   "I, too, believe that they should not wear such type of clothes while going to church. For other places, it is ok.",
  //   "The family should not be judged for what they are wearing.",
  //   "I think people should never wear such type of clothes."
  //   ]
  // },
  // {
  //   "question" : "Looking at a Punjabi boy, Shakti, Aryan cracks a joke on a sardar. The entire group starts laughing, looking at Shakti. As an observer, what will be your reaction?",
  //   "chooseAns" : [
  //   "I will also start laughing, looking at Shakti.",
  //   "I will laugh on the joke but certainly not look at Shakti.",
  //   "In order to ensure that I do not hurt Shakti’s feelings, I will not laugh on the joke."
  //   ]
  // },
  // {
  //   "question" : "The Geography teacher, while teaching a lesson on ‘Population’ discusses about population explosion in various nations and its impact. Hetal, after a deep thought, makes a remark that the problem of population explosion can be solved by asking people to go back to the country of origin of their religion. What is the first thought that will come to your mind after listening to Hetal?",
  //   "chooseAns" : [
  //   "This will not solve the problem as it will lead to population explosion in other nations.",
  //   "Certainly, I agree with what Hetal says.",
  //   "Variety is the spice of life. We cannot have nations with all people belonging to the same religion."
  //   ]
  // },
  // {
  //   "question" : "Looking at a Parsi family, Rehaan tells Christopher that Parsis talk only with other Parsis. They do not mingle with others. If you were their friend, what would you say?",
  //   "chooseAns" : [
  //   "I would tell them that we hardly know about Parsis and their way of life. So, let us not say this about them.",
  //   "I would agree with them.",
  //   "I would not say anything as I don’t know much about Parsis."
  //   ]
  // },
  // {
  //   "question" : "Touching upon a topic on Buddhism while teaching History, the teacher announces that the school has invited someone to talk about Buddhism. She announces the date and says that all of them should be present on that day. Consider yourself to be a part of this class. What thoughts would come to your mind?",
  //   "chooseAns" : [
  //   "I would wish they would have kept an extra Sports period instead.",
  //   "I wouldn’t be interested in attending it.",
  //   "I would be happy to learn about Buddhism."
  //   ]
  // },
  // {
  //   "question" : "A group of boys in a class tease their Gujarati classmates by the names of famous Gujarati foods. The Gujarati classmates get upset whenever they do so. What will you do in this situation?",
  //   "chooseAns" : [
  //   "Nothing. Because I think they should not take it so personally and get upset about it.",
  //   "I will inform the class teacher about it.",
  //   "I will first talk to the group of boys and then inform the class teacher."
  //   ]
  // },
  // {
  //   "question" : "Rose Mary’s family recently shifted to a new locality. She is finding it difficult to adjust and make new friends. To make the situation worse, some of your friends bully her. What would you do in this situation?",
  //   "chooseAns" : [
  //   "I will try to stop my friends as it is wrong to bully someone.",
  //   "I will try to stop my friends and ask Rose Mary to be a part of our group.",
  //   "I will not say anything to my friends as I fear losing them."
  //   ]
  // },
  // {
  //   "question" : "In one of the classrooms of a school where an elocution competition will be conducted very soon, the teacher announces that they have to participate in pairs. Priti, a student belonging to the Dalit community, has stammering problem; She stammers only when she is nervous. She wants to participate but no one from the class wants to be her partner. If you were a part of the class, what would you have done?",
  //   "chooseAns" : [
  //   "I would have also refused to be her partner because she belongs to the Dalit community.",
  //   "I would have refused because she has stammering problem.",
  //   "I would be ready to be her partner."
  //   ]
  // },
  // {
  //   "question" : "For a football match at inter-school level, Jasbeer, a Punjabi boy, represents his school. His entire team has worked very hard for the past one year. Their roles are made clear to them by the coach. On the day of the match, the coach takes an emergency move by asking Jasbeer to take the penalty shots. Different players of the team reacted in different ways. How do you see yourself reacting?",
  //   "chooseAns" : [
  //   "Why him? He will mess up and we would end up losing the aims.",
  //   "He has won many school level matches earlier and is definitely right for this task.",
  //   "A coach is the right person to decide for the team but I don’t think Jasbeer is a good choice."
  //   ]
  // },
  // {
  //   "question" : "While the History teacher is teaching a lesson on Mughals, A student, Ravi, makes a comment that Mughals have only caused devastation in India. Hearing this, Iqbal gets disturbed and complains to the teacher that Ravi passes such remarks frequently. What do you think about the whole situation?",
  //   "chooseAns" : [
  //   "I agree with Ravi. Mughals have only caused devastation.",
  //   "I think that in a History class, the contribution of Mughals should also be highlighted.",
  //   "I support Iqbal. Ravi should not make such comments."
  //   ]
  // },
  // ];
  // next step
  $scope.response = [];
  $scope.getAnswer = {
    id:''
  }
  $scope.checkRadio = false;
  var obj = {};
  $scope.nextStep = function(){
    if($scope.viewStep < $scope.stepsQa.length - 1){
      $scope.viewStep++;
      $scope.response.push(obj);
      console.log($scope.response,'response');
    }
    $scope.checkRadio = false;
  }
  // next step end
  $scope.prevStep = function(){
    $scope.viewStep--;
    $scope.checkRadio = false;
    $scope.response.pop();
  }

  $scope.setValue = function(ansId,qtsId){
    obj = {};
    var studId = localStorage.getItem('studentId');
    var schoolId = localStorage.getItem('schoolId');
    obj = {
      student_id : studId,
      school_id: schoolId,
      answer_id: ansId,
      question_id : qtsId
    }
    console.log(obj,'obj');
  }

  // send data
  $scope.sendData = function(){
    var responseObject = {
      responses: $scope.response
    };
    $http.post('https://rocky-sea-46108.herokuapp.com/api/responses/new', responseObject).then(function(getData){
      if (getData) {
        console.log(getData,'getData');
        localStorage.clear();
      }
    })
  }
  // send data end

})

.controller('RegisterUserCtrl', function($scope, $stateParams,$http,$state) {
  $scope.schoolList = [];
  $scope.register = {};
  $scope.schoolId = {
    id: '',
    class: ''
  }
  $scope.classList = ['A','B','C','D','E','F','G','H','I'];
  $scope.recordExists = false;
  // get api for school list
  $scope.getSchoolList = function(){
    $http.get('https://rocky-sea-46108.herokuapp.com/api/schools').then(function(response){
      if (response) {
        $scope.schoolList = response.data.data;
        console.log($scope.schoolList,'list');
        $scope.$evalAsync();
      }
    })
  };
  $scope.getSchoolList();
  // get api for school list end

  // registerUser
  $scope.registerUser = function(userDetail){
    userDetail.school_id = $scope.schoolId.id;
    userDetail.class = $scope.schoolId.class;
    $http.post('https://rocky-sea-46108.herokuapp.com/api/students/new', userDetail).then(function(response){
      console.log(response,'response');
      if (response.data.status == "success") {
        localStorage.setItem('schoolId', userDetail.school_id);
        localStorage.setItem('studentId',response.data.data);
        $state.go('app.playlists');
      }else {
        $scope.recordExists = true;
        setTimeout(function(){
          $scope.recordExists = false;
        },10000);
      }
    })
  }
  // registerUser end

})

.controller('AdminLoginCtrl', function($scope, $stateParams) {
})

.controller('AdminCtrl', function($scope, $stateParams, $http) {  
  $scope.listSchools = [];
  $scope.addSchoolName = {
    name: ''
  };

    // get api for school list
  $scope.getSchoolList = function(){
    $http.get('https://rocky-sea-46108.herokuapp.com/api/schools').then(function(response){
      if (response) {
        $scope.listSchools = response.data.data;
        $scope.$evalAsync();
      }
    })
  };
  $scope.getSchoolList();
  // get api for school list end
  // add School name
  $scope.addName = function(name){
    var addNameSchool = {
      name: name
    };
    $http.post('https://rocky-sea-46108.herokuapp.com/api/schools/new', addNameSchool).then(function(response){
      if (response.data.status == 'success') {
        $scope.listSchools.push(addNameSchool);
        $scope.addSchoolName.name = '';
      }
    })
  }
  // add School name end
})

.controller('StatisticCtrl', function($scope, $stateParams, $http) {
  $scope.allSchoolData = [];
  $scope.standardData = [];
  $scope.classData = [];
  var obj = {};
  $scope.viewSchool = true;
  $scope.viewStd = false;
  $scope.viewClass = false;
  $scope.studentList = false;

  $scope.getSchoolData = function(){
    $http.post('https://rocky-sea-46108.herokuapp.com/api/responses/show/school',obj).then(function(response){
      if (response.data.status == 'success') {
        $scope.allSchoolData = response.data.data;
        console.log(response,'response', $scope.allSchoolData);
      }
    })
  };
  $scope.getSchoolData();

  $scope.viewByStd = function(schoolId){
    obj.school_id = schoolId;
    $http.post('https://rocky-sea-46108.herokuapp.com/api/responses/show/standard',obj).then(function(response){
      console.log(response,'response');
      if (response.data.status == 'success') {
        $scope.standardData = response.data.data;
        $scope.viewByStd = true;
        $scope.viewClass = false;
        $scope.viewSchool = false;
      }
    })
  }

  $scope.viewByClass = function(stdId){
    obj.standard = stdId;
    $http.post('https://rocky-sea-46108.herokuapp.com/api/responses/show/class', obj).then(function(response){
      console.log(response,'response');
      if (response.data.status == 'success') {
        $scope.classData =  response.data.data;
        $scope.viewByStd = false;
        $scope.viewClass = true;
        $scope.viewSchool = false;
      }
    })
  }

  $scope.viewClassDetails =  function(classId){
    obj.class = classId;
    $http.post('https://rocky-sea-46108.herokuapp.com/api/responses/show/students', obj).then(function(response){
      console.log(response,'response');
      if (response.status == 200) {
        $scope.allDetails = response.data;
        $scope.viewByStd = false;
        $scope.viewClass = false;
        $scope.viewSchool = false;
        $scope.studentList = true;
      }
    })
  }

  $scope.getStudentReport = function(studentId){
    var studentDetails = {
      student_id: studentId
    }
    $http.post('https://rocky-sea-46108.herokuapp.com/api/responses/show/studentreport',studentDetails).then(function(response){
      console.log(response,'response student');
    })
  }
})

.controller('PlaylistCtrl', function($scope, $stateParams) {
});
